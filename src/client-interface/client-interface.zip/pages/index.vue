<template>
    <div>
        <h2 class="text-2xl font-bold mb-6">Welcome to the Dashboard</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Sample metric cards -->
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-medium">Active Users</h3>
                <p class="text-2xl mt-2">50</p>
            </div>
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-medium">Total Page Views</h3>
                <p class="text-2xl mt-2">1200</p>
            </div>
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-medium">Sessions by Device</h3>
                <p class="text-2xl mt-2">300 Mobile, 200 Desktop</p>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { useHead } from 'nuxt/app'

    useHead({
        title: 'Dashboard - Overview'
    })
</script>
